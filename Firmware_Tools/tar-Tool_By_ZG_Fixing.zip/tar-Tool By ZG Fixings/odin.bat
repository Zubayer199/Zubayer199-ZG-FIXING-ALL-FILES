@ECHO OFF
cd bin
start odin3.exe