@echo ---------------mkh.mourad batch script
rem run ImgToTar.md5.batch instead of this batch file for creating a log file of the operation.

rem clean directoies from old tar and tar.md5 files
FOR /f "delims=" %%G in ('DIR /S /A:-D /B *.tar') do del "%%G"
FOR /f "delims=" %%G in ('DIR /S /A:-D /B *.tar.md5') do del "%%G"


rem first create a backup files from *.img in the same directory
FOR /f "delims=" %%G in ('DIR /S /A:-D /B *.img *.bin') do XCOPY /Y  "%%G" "%%G.back" < Yes_File
rem rename img files started by recovery to recovery.img and
rem img files started by boot or kernel to boot.img
FOR /f "delims=" %%G in ('DIR /S /A:-D /B recovery*.img') do REN "%%G" recovery.img
FOR /f "delims=" %%G in ('DIR /S /A:-D /B boot*.img') do REN "%%G" boot.img
FOR /f "delims=" %%G in ('DIR /S /A:-D /B kernel*.img') do REN "%%G" boot.img
FOR /f "delims=" %%G in ('DIR /S /A:-D /B modem*.bin') do REN "%%G" modem.bin
FOR /f "delims=" %%G in ('DIR /S /A:-D /B NON-HLOS*.bin') do REN "%%G" NON-HLOS.bin


rem Create the tar file:
SETLOCAL ENABLEDELAYEDEXPANSION
rem // clear previous files.
RMDIR /S /Q AllFiles
MKDIR AllFiles
call set curentDir="%cd%%"
FOR /f "delims=" %%G in ('DIR /S /A:-D /B  *.img *.bin') do (
	call cd %%~dpG
	call !curentDir!\BIN\tar --create --format=gnu -b20 --quoting-style=escape --owner=0 --group=0 --totals --mode=644  -f %%~nG.tar %%~nxG
	xcopy %%~nxG  !curentDir!\AllFiles\
	)
cd !curentDir!	


rem Creat a AllInOne Tar file for all img and bin files
cd AllFiles
call !curentDir!\BIN\ls *.img *.bin > allfiles.txt
call !curentDir!\BIN\tar --create --format=gnu -b20 --quoting-style=escape --owner=0 --group=0 --totals --mode=644  -f allfiles.tar -T allfiles.txt
del /Q allfiles.txt
cd !curentDir!	


rem Create the md5 final file:
FOR /f "delims="  %%G in ('DIR /S /A:-D /B  *.tar') do (
	call cd %%~dpG
	call !curentDir!\BIN\md5sum -t %%~nxG >> %%~nxG
	call !curentDir!\BIN\mv %%~nxG %%~nxG.md5
	)
cd !curentDir!
	
rem clean directoies from img and bin files
FOR /f "delims=" %%G in ('DIR /S /A:-D /B *.img *.bin') do del /Q "%%G"
